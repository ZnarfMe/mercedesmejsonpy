mercedesmejsonpy
===============

Python module for Mercedes ME API

This is a work in progress and will focus only on integration into Home Assistant.

* Based on https://github.com/zabuldon/teslajsonpy
